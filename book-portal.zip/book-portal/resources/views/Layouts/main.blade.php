@include('Layouts.header')
@yield('main_section')
@include('Layouts.footer')