<footer class="text-light py-3">
  <div class="container bg-dark-footer text-center">
    <p class="mb-0 para">&copy; 2023 BOOKIES. All rights reserved.</p>
  </div>
  
            <div class="col-md-12 text-center">
                <ul class="list-inline social-media">
                    <li class="list-inline-item"><a href="https://www.facebook.com/nabeelmehdi.emraani"><i class="fab fa-facebook-f light"></i></a></li>
                    <li class="list-inline-item"><a href="https://twitter.com/i/flow/single_sign_on"><i class="fab fa-twitter light"></i></a></li>
                    <li class="list-inline-item"><a href="https://www.instagram.com/billu_badshaw/"><i class="fab fa-instagram light"></i></a></li>
                </ul>
              
          
    </div>
</footer>
