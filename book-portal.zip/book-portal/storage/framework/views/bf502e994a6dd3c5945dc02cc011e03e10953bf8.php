

<?php $__env->startSection('main_section'); ?>
<?php $__env->startPush('title'); ?>
    <title>View</title>
    <?php $__env->stopPush(); ?>
    <table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Author</th>
            <th>Edition</th>
            <th>No of Pages</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($book->Name); ?></td>
            <td><?php echo e($book->author); ?></td>
            <td><?php echo e($book->edition); ?></td>
            <td><?php echo e($book->no_of_pages); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\book-portal\resources\views/View.blade.php ENDPATH**/ ?>