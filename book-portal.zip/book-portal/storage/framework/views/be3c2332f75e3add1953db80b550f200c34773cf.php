

<?php $__env->startSection('main_section'); ?>
<?php $__env->startPush('title'); ?>
<title>Store</title>
<?php $__env->stopPush(); ?>


  <body>
    
    <div class="container-form">
    <a href="<?php echo e(route('view')); ?>" class=" btn-icon-right">
  <i class="fas fa-eye"></i> 
</a>
      <h2>Add Book Form</h2>
      

      <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form action="<?php echo e(isset($books) ? route('update', ['id' => $books->ID]) : route('store')); ?>" method="POST" >
    <?php echo csrf_field(); ?>
    <?php if(isset($books)): ?>
       
    <?php endif; ?>
    <label for="title">Title:</label>
    <input type="text" class="form-control" name="title" value="<?php echo e(isset($books) ? $books->Title : old('title')); ?>">
    <span class="text-danger">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span><br>
    <label for="author">Author:</label>
    <input type="text" id="author" class="form-control" name="author" value="<?php echo e(isset($books) ? $books->Author : old('author')); ?>">
    <span class="text-danger">
        <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span><br>
    <label for="edition">Edition:</label>
    <input type="text" id="edition" name="edition" class="form-control" value="<?php echo e(isset($books) ? $books->Edition : old('edition')); ?>">
    <span class="text-danger">
        <?php $__errorArgs = ['edition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span><br>
    <label for="num_pages">Number of Pages:</label>
    <input type="number" id="num_pages" name="num_pages" class="form-control" value="<?php echo e(isset($books) ? $books->No_of_Pages : old('num_pages')); ?>">
    <span class="text-danger">
        <?php $__errorArgs = ['num_pages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span><br>

    <button type="submit" class="btn btn-primary">
        <?php if(isset($books)): ?>
            Save Changes
        <?php else: ?>
            Add Book
        <?php endif; ?>
    </button>
</form>

    </div>
  </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\book-portal\resources\views/store.blade.php ENDPATH**/ ?>