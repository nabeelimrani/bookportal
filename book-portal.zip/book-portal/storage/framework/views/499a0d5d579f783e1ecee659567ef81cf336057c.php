<?php $__env->startSection('main_section'); ?>
<?php $__env->startPush('title'); ?>
<title>Book Dashboard</title>
<?php $__env->stopPush(); ?>

<div class="container">
  <h1>Book Dashboard</h1>
  <div class="row">
    <div class="col-md-4">
      <div class="card bg-primary text-white mb-3 radius">
        <div class="card-body">
          <h5 class="card-title">Total Books</h5>
          <p class="card-text light"><?php echo e($bookCount); ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card bg-success text-white mb-3 radius">
        <div class="card-body ">
          <h5 class="card-title">Available Books</h5>
          <p class="card-text light">300</p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card bg-danger text-white mb-3 radius">
        <div class="card-body">
          <h5 class="card-title">Borrowed Books</h5>
          <p class="card-text light">200</p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\book-portal\resources\views/Home.blade.php ENDPATH**/ ?>