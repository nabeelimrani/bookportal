

<?php $__env->startSection('main_section'); ?>
<?php $__env->startPush('title'); ?>
    <title>View</title>
<?php $__env->stopPush(); ?>
<div class="container-table">
  <?php if(session('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
  <table class="custom-table">
    <thead>
      <tr>
        <th>Book Title</th>
        <th>Author</th>
        <th>Edition</th>
        <th>No. of Pages</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($book->title); ?></td>
          <td><?php echo e($book->author); ?></td>
          <td><?php echo e($book->edition); ?></td>
          <td><?php echo e($book->no_of_pages); ?></td>
          <td>
            <a href="<?php echo e(route('edit',['id'=>$book->id])); ?>" class="custom-btn custom-btn-edit"><i class="fas fa-edit"></i>  </a>
            <a href="<?php echo e(route('del',['id'=>$book->id])); ?>" class="custom-btn custom-btn-delete"><i class="fas fa-trash"></i>  </a> 
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\book-portal\resources\views/view.blade.php ENDPATH**/ ?>